export default function Dashboard() {
  return (
    <div className="flex h-full flex-col items-center justify-center">
      <h1 className="text-2xl font-bold">Dashboard</h1>
    </div>
  );
}
